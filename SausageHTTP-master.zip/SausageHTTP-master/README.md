# SausageHTTP
 A lightweight PHP library for sending HTTP requests
 
# Usage
 Pull the SausageHTTP file and include/require to your PHP project

